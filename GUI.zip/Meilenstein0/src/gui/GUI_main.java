package gui;

public class GUI_main {

	public static void main(String [] args) {
		new MyFrame();
	}
}
